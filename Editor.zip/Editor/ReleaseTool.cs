using UnityEngine;
using System.Collections;
using UnityEditor;

public class ReleaseTool : MonoBehaviour {

	static void BuildAndroid()
	{
		string output_path = Application.dataPath.Substring(0, Application.dataPath.Length - 6) ;
		string[]load_levels = {"assets/1.unity"};
		UnityEditor.BuildPipeline.BuildPlayer(load_levels,output_path+"k2.pkg",BuildTarget.Android,BuildOptions.None);
	}
	
	static void BuildiOS()
	{
		string output_path = Application.dataPath.Substring(0, Application.dataPath.Length - 6) ;
		string[]load_levels = {"assets/1.unity"};
		UnityEditor.BuildPipeline.BuildPlayer(load_levels,output_path+"xcode/",BuildTarget.iPhone,BuildOptions.None);
	}
}
